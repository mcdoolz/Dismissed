# Dismissed

A Chrome plug in for dismissing LinkedIn job results by string.
