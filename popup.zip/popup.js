document.addEventListener('DOMContentLoaded', function () {
  const companyInput = document.getElementById('companyInput');
  const titleInput = document.getElementById('titleInput');
  const companyTags = document.getElementById('companyTags');
  const titleTags = document.getElementById('titleTags');
  const saveButton = document.getElementById('saveButton');
  const clearButton = document.getElementById('clearButton');
  const dismissButton = document.getElementById('dismissButton');

  // Load saved data
  chrome.storage.sync.get(['companies', 'titles'], function (result) {
    if (result.companies) displayTags(result.companies, companyTags);
    if (result.titles) displayTags(result.titles, titleTags);
  });

  // Save data
  saveButton.addEventListener('click', function () {
    const companies = companyInput.value.split(',').map(item => item.trim()).filter(Boolean);
    const titles = titleInput.value.split(',').map(item => item.trim()).filter(Boolean);

    chrome.storage.sync.set({ companies, titles }, function () {
      displayTags(companies, companyTags);
      displayTags(titles, titleTags);
      companyInput.value = '';
      titleInput.value = '';
    });
  });

  // Clear data
  clearButton.addEventListener('click', function () {
    chrome.storage.sync.set({ companies: [], titles: [] }, function () {
      companyTags.innerHTML = '';
      titleTags.innerHTML = '';
    });
  });

  // Dismiss jobs
  dismissButton.addEventListener('click', function () {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      chrome.storage.sync.get(['companies', 'titles'], function (result) {
        chrome.tabs.executeScript(
          tabs[0].id,
          { code: `(${dismissJobs})(${JSON.stringify(result.companies)}, ${JSON.stringify(result.titles)})` }
        );
      });
    });
  });

  function displayTags(items, container) {
    container.innerHTML = '';
    items.forEach(item => {
      const tag = document.createElement('span');
      tag.className = 'tag';
      tag.textContent = item;

      const removeButton = document.createElement('button');
      removeButton.textContent = 'x';
      removeButton.addEventListener('click', function () {
        removeTag(item, items, container);
      });

      tag.appendChild(removeButton);
      container.appendChild(tag);
    });
  }

  function removeTag(item, items, container) {
    const index = items.indexOf(item);
    if (index > -1) {
      items.splice(index, 1);
      chrome.storage.sync.set({
        companies: container === companyTags ? items : undefined,
        titles: container === titleTags ? items : undefined
      }, function () {
        displayTags(items, container);
      });
    }
  }
});

function dismissJobs(companiesToDismiss, titlesToDismiss) {
  const jobCards = document.querySelectorAll('.job-card-container');

  for (const card of jobCards) {
    const companyName = card.querySelector('.job-card-container__primary-description').textContent.trim();
    const jobTitle = card.querySelector('.job-card-container__link').textContent.trim();

    const shouldDismiss = companiesToDismiss.some(company => companyName.toLowerCase().includes(company.toLowerCase())) ||
      titlesToDismiss.some(title => jobTitle.toLowerCase().includes(title.toLowerCase()));

    if (shouldDismiss) {
      // Check if the job is already dismissed
      const alreadyDismissed = card.querySelector('.job-card-container__footer-item--highlighted');
      if (alreadyDismissed && alreadyDismissed.textContent.includes("We won't show you this job again")) {
        console.log(`Job "${jobTitle}" from ${companyName} is already dismissed`);
        continue; // Skip to the next job card
      }

      const dismissButton = card.querySelector('.job-card-container__action');

      if (dismissButton) {
        dismissButton.click();
        console.log(`Dismissed job "${jobTitle}" from ${companyName}`);
      } else {
        console.log(`Dismiss button not found for job "${jobTitle}" from ${companyName}`);
      }
    }
  }
}